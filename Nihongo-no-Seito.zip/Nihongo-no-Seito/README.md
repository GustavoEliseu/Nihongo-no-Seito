# Nihongo-no-Seito
Aplicativo com o objetivo de auxiliar no aprendizado da escrita e leitura japonesa, para ser utilizado em conjunto com os livros "Marugoto".

<img src="https://raw.githubusercontent.com/GustavoEliseu/Nihongo-no-Seito/master/REMOVER/TelaPrincipal.png" width="135" 
height="240">
<img src="https://raw.githubusercontent.com/GustavoEliseu/Nihongo-no-Seito/master/REMOVER/TelaKanji.png" width="135" 
height="240">
<img src="https://raw.githubusercontent.com/GustavoEliseu/Nihongo-no-Seito/master/REMOVER/TelaProgresso.png" width="135" 
height="240">
<img src="https://raw.githubusercontent.com/GustavoEliseu/Nihongo-no-Seito/master/REMOVER/TelaVocab.png" width="135" 
height="240">
