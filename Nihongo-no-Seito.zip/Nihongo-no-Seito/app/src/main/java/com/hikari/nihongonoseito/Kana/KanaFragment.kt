package com.hikari.nihongonoseito.Kana

import android.content.Context
import android.os.Bundle
import android.support.annotation.NonNull
import android.support.design.widget.BottomNavigationView
import android.support.v4.app.Fragment
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.hikari.nihongonoseito.R
import kotlinx.android.synthetic.main.fragment_kana_list.*
import kotlinx.android.synthetic.main.fragment_kana_list.view.*

/**
 * A fragment representing a list of Items.
 * Activities containing this fragment MUST implement the
 * [KanaFragment.OnListFragmentInteractionListener] interface.
 */
class KanaFragment : Fragment(), SimpleAdapter.ItemClickListener {

    // TODO: Customize parameters
    private var columnCount = 1
    private lateinit var myTopBar: BottomNavigationView
    private var listener: OnListFragmentInteractionListener? = null
    private var telaAtual: Boolean = true //True = Hiragana, False = Katakana
    private lateinit var mRecyclerViewKana:RecyclerView
    private lateinit var myRecyclerAdapterKana:RecyclerView.Adapter<RecyclerView.ViewHolder>

    val mOnNavigationItemSelectedListener: BottomNavigationView.OnNavigationItemSelectedListener = object : BottomNavigationView.OnNavigationItemSelectedListener {
        var BoolRetorno: Boolean = false
        override fun onNavigationItemSelected(@NonNull item: MenuItem): Boolean {
            val id = item.getItemId()
            when (id) {
                R.id.nav_home -> {
                    telaAtual = true;
                    changeHiraKata(telaAtual)
                    BoolRetorno=true
                }

                R.id.nav_kana -> {
                    telaAtual = false
                    changeHiraKata(telaAtual)
                    BoolRetorno=true
                }
            }
            return BoolRetorno
        }
    }

    private fun changeHiraKata(hiraOuKataBollean: Boolean) {
        var numberOfItens = 0
        val imgWidth = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 40f, resources.displayMetrics)
        val mItemArray: java.util.ArrayList<Kana>
        val itemNulo = Kana("")
        val HiraKata:String = if(hiraOuKataBollean) "Hira" else "Kata"



        //This is the code to provide a sectioned grid
        val sections = java.util.ArrayList<SectionedGridRecyclerViewAdapter.Section>()

        var contador = 0

        numberOfItens = resources.getStringArray(R.array.kanas_basic).size + resources.getStringArray(R.array.kanas_var).size + resources.getStringArray(R.array.kanas_jun).size
        sections.add(SectionedGridRecyclerViewAdapter.Section(0, "Basico"))
        sections.add(SectionedGridRecyclerViewAdapter.Section(55, "Váriaveis"))
        sections.add(SectionedGridRecyclerViewAdapter.Section(80, "Junções"))
        mItemArray = ArrayList<Kana>(numberOfItens)
        for (i in 0 until numberOfItens) {
            if (i < 55) {
                if (resources.getStringArray(R.array.kanas_basic)[i].equals("z")) contador++
                mItemArray.add(i, Kana(resources.getStringArray(R.array.kanas_basic)[i], resources.getDrawable(resources.getIdentifier(HiraKata + "_bas" + (i + 1 - contador), "drawable", context?.packageName)), false))
            } else if (i < 80) {
                mItemArray.add(i, Kana(resources.getStringArray(R.array.kanas_var)[i - 55], resources.getDrawable(resources.getIdentifier(HiraKata + "_var" + (i - 54), "drawable", context?.packageName)), false))
            } else {
                mItemArray.add(i, Kana(resources.getStringArray(R.array.kanas_jun)[i - 80], resources.getDrawable(resources.getIdentifier(HiraKata + "_jun" + (i - 79), "drawable", context?.packageName)), true))
            }
        }
        val layoutManager = GridLayoutManager(context, 15)

        myRecyclerkana.setLayoutManager(layoutManager)
        //Your RecyclerView.Adapter
        if(context!=null){
        myRecyclerAdapterKana = SimpleAdapter(context, mItemArray, imgWidth, true) as RecyclerView.Adapter<RecyclerView.ViewHolder>
        (myRecyclerAdapterKana as SimpleAdapter).setmClickListener(this)
        }
    }

    override fun onItemClick(view: View, position: Int) {
        Toast.makeText(context, mRecyclerViewKana.getChildViewHolder(view).getItemViewType().toString() + " " + position, Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        arguments?.let {
            columnCount = it.getInt(ARG_COLUMN_COUNT)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_kana_list, container, false)
        myTopBar=view.myTopNavigation
        myTopBar.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)
        // Set the adapter
        mRecyclerViewKana=view.myRecyclerkana
        if (mRecyclerViewKana is RecyclerView) {
            with(view) {
                val layoutManager = when {
                    columnCount <= 1 -> LinearLayoutManager(context)
                    else -> GridLayoutManager(context, columnCount)
                }

                changeHiraKata(telaAtual)
            }
        }
        return view
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is OnListFragmentInteractionListener) {
            listener = context
        } else {
            throw RuntimeException(context.toString() + " must implement OnListFragmentInteractionListener")
        }
    }

    override fun onDetach() {
        super.onDetach()
        listener = null
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     *
     *
     * See the Android Training lesson
     * [Communicating with Other Fragments](http://developer.android.com/training/basics/fragments/communicating.html)
     * for more information.
     */
    interface OnListFragmentInteractionListener {
        // TODO: Update argument type and name
        fun onListFragmentInteraction(item: Kana?)
    }

    companion object {

        // TODO: Customize parameter argument names
        const val ARG_COLUMN_COUNT = "column-count"

        // TODO: Customize parameter initialization
        @JvmStatic
        fun newInstance(columnCount: Int) =
                KanaFragment().apply {
                    arguments = Bundle().apply {
                        putInt(ARG_COLUMN_COUNT, columnCount)
                    }
                }
    }
}
